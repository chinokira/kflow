package kayak.freestyle.competition.kflow.dto;

public interface HasId {

    long getId();

    void setId(long id);
}
