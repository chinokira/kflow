package kayak.freestyle.competition.kflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
